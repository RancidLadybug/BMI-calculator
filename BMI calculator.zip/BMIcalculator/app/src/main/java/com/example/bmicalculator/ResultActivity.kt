package com.example.bmicalculator

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ResultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        val resultText = findViewById<TextView>(R.id.resultText)
        val btnBack = findViewById<Button>(R.id.btnBack)

        // Get the BMI data sent from MainActivity
        val bmiValue = intent.getFloatExtra("bmi_value", 0f)
        val bmiCategory = intent.getStringExtra("bmi_category")

        // Show the result
        val displayText = "Your BMI is %.2f\nYou are in the %s.".format(bmiValue, bmiCategory)
        resultText.text = displayText

        // Go back button
        btnBack.setOnClickListener {
            finish()
        }
    }
}

package com.example.bmicalculator

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val weightInput = findViewById<TextInputEditText>(R.id.weight)
        val heightInput = findViewById<TextInputEditText>(R.id.height)
        val btnSubmit = findViewById<Button>(R.id.btnSubmit)

        btnSubmit.setOnClickListener {
            val weightStr = weightInput.text.toString()
            val heightStr = heightInput.text.toString()

            if (weightStr.isEmpty() || heightStr.isEmpty()) {
                weightInput.error = "Required"
                heightInput.error = "Required"
                return@setOnClickListener
            }

            val weight = weightStr.toFloat()
            val heightM = heightStr.toFloat() / 100
            val bmi = weight / (heightM * heightM)

            val category = when {
                bmi < 18.5 -> "Underweight"
                bmi in 18.5..24.9 -> "Healthy Weight Range"
                bmi in 25.0..29.9 -> "Overweight"
                else -> "Obese"
            }

            // Move to next page (ResultActivity)
            val intent = Intent(this, ResultActivity::class.java)
            intent.putExtra("bmi_value", bmi)
            intent.putExtra("bmi_category", category)
            startActivity(intent)
        }
    }
}

